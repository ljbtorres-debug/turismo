import { Injectable, inject } from '@angular/core';
import { AlertController, AlertOptions, LoadingController, ModalController, ModalOptions, ToastController, ToastOptions } from '@ionic/angular';
import { Router } from '@angular/router';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

@Injectable({
  providedIn: 'root',
})
export class UtilsService {
  loadingCtrl = inject(LoadingController);
  toastCtrl = inject(ToastController);
  router = inject(Router);
  modalCtrl = inject(ModalController)
  alerCtrl = inject(AlertController)

  //===== Camara =====


 async takePicture(promptLabelHeader: string) {
  return await Camera.getPhoto({
    quality: 90,
    allowEditing: true,
    resultType: CameraResultType.DataUrl,
    source: CameraSource.Prompt, 
    promptLabelHeader,
    promptLabelCancel: 'Cancelar',
    promptLabelPhoto: 'Usar foto',
    promptLabelPicture: 'Tomar foto',
  });

  
};

async presentAlert(opts?: AlertOptions) {
  const alert = await this.alerCtrl.create(opts);

  await alert.present();
}

  //===== Loading =====
  loading() {
    return this.loadingCtrl.create({ spinner: 'bubbles' })

  }

  //===== Toast =====
 async presentToast(opts?: {
  message: string;
  duration?: number;
  position?: 'top' | 'middle' | 'bottom';
  color?: string;
  icon?: string;
}) {
  const toast = await this.toastCtrl.create({
    message: opts.message,
    duration: opts.duration || 2500,
    position: opts.position || 'bottom',
    color: opts.color,
    icon: opts.icon,
    cssClass: 'custom-toast',  // Clase personalizada
  });
  toast.present();
}

  //===== Enruta a cualquier pagina disponible =====

  routerLink(url: string) {
    return this.router.navigateByUrl(url);
  }

  //===== Guardar en localstorage =====

  saveInLocalStorage(key: string, value: any) {
    return localStorage.setItem(key, JSON.stringify(value));
  }

  //===== Obtener de localstorage =====

  getFromLocalStorage(key: string) {
    return JSON.parse(localStorage.getItem(key));
  }

    //===== Convertir File a base64 (para imagen/audio/video) =====
  fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);

      reader.readAsDataURL(file);
    });
  }
  
  //===== MODAL =====
  async presentModal(opts: ModalOptions) {
    const modal = await this.modalCtrl.create(opts);
    await modal.present();

    const { data } = await modal.onWillDismiss();
    if (data) return data;
    }

    dismissModal(data?: any) {
      return this.modalCtrl.dismiss(data);
    }

}
    