export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAYriBrhAf7rHb7V0u-UW6GsGdzhn7Qno0",
    authDomain: "produc-admin-j.firebaseapp.com",
    projectId: "produc-admin-j", // ← Asegúrate que sea consistente
    storageBucket: "produc-admin-j.firebasestorage.app",
    messagingSenderId: "556055499753",
    appId: "1:556055499753:web:3581b06e7ec7e98a1af178"
  }
};
